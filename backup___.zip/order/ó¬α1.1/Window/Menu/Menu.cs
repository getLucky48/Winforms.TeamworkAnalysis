﻿using System;
using System.Windows.Forms;
using WinFormInfSys.Window;
using static WinFormInfSys.Auth;

namespace WinFormInfSys
{
    public partial class Menu : Form
    {

        public Menu()
        {

            InitializeComponent();
            
        }

        public Menu(Tuple<Role, int> role)
        {

            InitializeComponent();

            if(role.Item1 != Role.Teacher)
            {

                TeacherPage.Enabled = false;
                DisciplinePage.Enabled = false;
                GroupPage.Enabled = false;
                AnalysisPage.Enabled = false;

            }

            this.role = role;

        }

        private Tuple<Role, int> role;

        private void пройтиТестБелбинаToolStripMenuItem_Click(object sender, EventArgs e)
        {

            this.Hide();
            TestBelbin belbin = new TestBelbin(role);
            belbin.ShowDialog();
            this.Show();

        }

        private void дисциплиныToolStripMenuItem1_Click(object sender, EventArgs e)
        {

            this.Hide();
            Disciplines disciplines = new Disciplines(role);
            disciplines.ShowDialog();
            this.Show();

        }

        private void сменитьПользователяToolStripMenuItem_Click(object sender, EventArgs e)
        {

            this.Close();

        }

        private void вызодToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Application.Exit();

        }

        private void добавитьДисциплинуToolStripMenuItem_Click(object sender, EventArgs e)
        {

            this.Hide();
            Teachers teachers = new Teachers();
            teachers.ShowDialog();
            this.Show();

        }

        private void изменениеГруппToolStripMenuItem_Click(object sender, EventArgs e)
        {

            this.Hide();
            Students students = new Students();
            students.ShowDialog();
            this.Show();

        }

        private void просмотрГруппToolStripMenuItem_Click(object sender, EventArgs e)
        {

            this.Hide();
            Group group = new Group();
            group.ShowDialog();
            this.Show();

        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {

            this.Hide();
            DisciplinesAll disciplines = new DisciplinesAll();
            disciplines.ShowDialog();
            this.Show();

        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {

            this.Hide();
            TaskAdd taskAdd = new TaskAdd(role);
            taskAdd.ShowDialog();
            this.Show();

        }

        private void результатыТестаToolStripMenuItem_Click(object sender, EventArgs e)
        {

            this.Hide();
            TestResults testRes = new TestResults();
            testRes.ShowDialog();
            this.Show();

        }

        private void создатьБригадыToolStripMenuItem_Click(object sender, EventArgs e)
        {



        }

    }

}
