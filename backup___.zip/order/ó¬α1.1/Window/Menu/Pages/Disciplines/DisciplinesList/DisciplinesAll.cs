﻿using MySql.Data.MySqlClient;
using System;
using System.Drawing;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using WinFormInfSys.Class;
using static WinFormInfSys.Auth;

namespace WinFormInfSys.Window
{
    public partial class DisciplinesAll : Form
    {

        public DisciplinesAll()
        {

            InitializeComponent();

            Binder.bind(TypeList, "is_typediscipline", "name_short");

            buildList();

        }

        private Label buildLabel(int parentWidth, int index, string text)
        {

            Label res = new Label();
            res.Width = parentWidth - res.Width - 10 - 20;
            res.Parent = Container;
            res.Text = text;
            res.Name = $"LabelNum{index}";
            res.Location = new Point(0, index * 25);

            return res;

        }
        private Button buildButton(int titleWidth, string text, int id, string name)
        {

            Button res = new Button();
            res.Text = text;
            res.Parent = Container;
            res.Width = titleWidth;
            res.AutoSize = false;
            res.Name = name;

            return res;

        }

        private void clearList()
        {

            Container.Controls.Clear();

        }

        private void buildList()
        {

            clearList();

            string query = $@"

                select isd.id as id, isd.name as discipline, istd.name_short as type from is_discipline isd

                left join is_typediscipline istd on istd.id = isd.type_Id

                order by isd.name

            ";

            MySqlConnection conn = DBUtils.getConnection();

            conn.Open();

            MySqlCommand cmd = new MySqlCommand(query, conn);

            MySqlDataReader reader = cmd.ExecuteReader();

            int i = 0;

            while (reader.Read())
            {

                string str = $"{reader["discipline"]}  [ {reader["type"]} ]";

                Label l = buildLabel((int)(Container.Width * 0.85), i, str);

                Button delete = buildButton((int)(Container.Width * 0.15), "Удалить", int.Parse(reader["id"].ToString()), $"ButtonDelete_{int.Parse(reader["id"].ToString())}");
                delete.Location = new Point(l.Location.X + l.Width + 5, l.Location.Y);
                delete.Click += Delete_Click;

                Button edit = buildButton((int)(Container.Width * 0.30), "Редактировать", int.Parse(reader["id"].ToString()), $"ButtonEdit_{int.Parse(reader["id"].ToString())}");
                edit.Location = new Point(delete.Location.X + delete.Width + 5, l.Location.Y);
                edit.Click += Edit_Click;

                i++;

            }

            conn.Close();

        }

        private void Edit_Click(object sender, EventArgs e)
        {

            int id = int.Parse(((Button)sender).Name.Replace("ButtonEdit_", string.Empty));

            _edit_DisciplinesAll dialog = new _edit_DisciplinesAll(id);

            dialog.ShowDialog();

            buildList();

        }

        private void Delete_Click(object sender, EventArgs e)
        {

            int id = int.Parse(((Button)sender).Name.Replace("ButtonDelete_", string.Empty));

            DialogResult dialogResult = MessageBox.Show("При удалении дисциплины также будут удалены все проекты, связанные с ней. Продолжить?", "Подтверждение", MessageBoxButtons.YesNo);

            if(dialogResult == DialogResult.No) { return; }

            string query = $@"

                delete from is_project where discipline_id = '{id}';
                delete from is_discipline where id = '{id}';

            ";

            DBUtils.execQuery(query);

            buildList();

        }

        private void Create_Click(object sender, EventArgs e)
        {

            string name = Name_disc.Text;
            string type = TypeList.SelectedItem.ToString();

            if (DBUtils.disciplineIsExists(name, type))
            {

                MessageBox.Show("Дисциплина с таким наименованием и типом уже существует");

                return;

            }

            if (string.IsNullOrWhiteSpace(name) || TypeList.SelectedIndex == -1)
            {

                MessageBox.Show("Проверьте правильность данных");

                return;

            }

            DBUtils.addDiscipline(name, type);

            buildList();

        }

    }

}
