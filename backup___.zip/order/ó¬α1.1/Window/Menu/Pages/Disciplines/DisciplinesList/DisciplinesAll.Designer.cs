﻿
namespace WinFormInfSys.Window
{
    partial class DisciplinesAll
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Container = new System.Windows.Forms.Panel();
            this.Editor = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Name_disc = new System.Windows.Forms.TextBox();
            this.Create = new System.Windows.Forms.Button();
            this.TypeList = new System.Windows.Forms.ComboBox();
            this.Editor.SuspendLayout();
            this.SuspendLayout();
            // 
            // Container
            // 
            this.Container.Location = new System.Drawing.Point(2, 3);
            this.Container.Name = "Container";
            this.Container.Size = new System.Drawing.Size(392, 382);
            this.Container.TabIndex = 0;
            // 
            // Editor
            // 
            this.Editor.Controls.Add(this.TypeList);
            this.Editor.Controls.Add(this.label2);
            this.Editor.Controls.Add(this.label1);
            this.Editor.Controls.Add(this.Name_disc);
            this.Editor.Controls.Add(this.Create);
            this.Editor.Location = new System.Drawing.Point(2, 391);
            this.Editor.Name = "Editor";
            this.Editor.Size = new System.Drawing.Size(392, 110);
            this.Editor.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(196, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(26, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Тип";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Наименование";
            // 
            // Name_disc
            // 
            this.Name_disc.Location = new System.Drawing.Point(18, 32);
            this.Name_disc.Name = "Name_disc";
            this.Name_disc.Size = new System.Drawing.Size(175, 20);
            this.Name_disc.TabIndex = 1;
            // 
            // Create
            // 
            this.Create.Location = new System.Drawing.Point(148, 73);
            this.Create.Name = "Create";
            this.Create.Size = new System.Drawing.Size(96, 21);
            this.Create.TabIndex = 0;
            this.Create.Text = "Создать";
            this.Create.UseVisualStyleBackColor = true;
            this.Create.Click += new System.EventHandler(this.Create_Click);
            // 
            // TypeList
            // 
            this.TypeList.FormattingEnabled = true;
            this.TypeList.Location = new System.Drawing.Point(199, 32);
            this.TypeList.Name = "TypeList";
            this.TypeList.Size = new System.Drawing.Size(175, 21);
            this.TypeList.TabIndex = 6;
            // 
            // DisciplinesAll
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(397, 497);
            this.Controls.Add(this.Editor);
            this.Controls.Add(this.Container);
            this.Name = "DisciplinesAll";
            this.Text = "Список дисциплин";
            this.Editor.ResumeLayout(false);
            this.Editor.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Container;
        private System.Windows.Forms.Panel Editor;
        private System.Windows.Forms.Button Create;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Name_disc;
        private System.Windows.Forms.ComboBox TypeList;
    }
}