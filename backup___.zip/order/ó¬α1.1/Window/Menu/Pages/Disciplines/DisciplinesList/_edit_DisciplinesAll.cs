﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormInfSys.Class;

namespace WinFormInfSys.Window
{
    public partial class _edit_DisciplinesAll : Form
    {
        public _edit_DisciplinesAll()
        {
            InitializeComponent();
        }
    
        public _edit_DisciplinesAll(int disc_id)
        {

            InitializeComponent();


            this.disc_id = disc_id;

            string query = $@"

                select isd.id as id, isd.name as discipline, istd.name_short as type from is_discipline isd

                join is_typediscipline istd on istd.id = isd.type_Id

                where isd.id = {this.disc_id}

            ";


            Binder.bind(TypeList, "is_typediscipline", "name_short");
            Binder.selectItem(TypeList, "is_discipline", "type_id", "is_typediscipline", "id", "name_short", this.disc_id);

            Binder.bind(Disc_name, "discipline", query);

        }

        private int disc_id { get; set; }

        private void Create_Click(object sender, EventArgs e)
        {

            string name = Disc_name.Text;
            string type = TypeList.SelectedItem.ToString();

            if (DBUtils.disciplineIsExists(name, type, this.disc_id))
            {

                MessageBox.Show("Дисциплина с таким наименованием и типом уже существует");

                return;

            }

            if (string.IsNullOrWhiteSpace(name))
            {

                MessageBox.Show("Проверьте правильность данных");

                return;

            }

            string query = $@"UPDATE is_discipline SET

                            name = '{name}', type_id = (select id from is_typediscipline where name_short = '{type}' limit 1)


                            WHERE id = '{this.disc_id}'

                            ";

            DBUtils.execQuery(query);

            this.Close();

        }

    }

}
