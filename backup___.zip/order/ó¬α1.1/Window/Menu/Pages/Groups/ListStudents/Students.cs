﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using WinFormInfSys.Class;
using static WinFormInfSys.Auth;

namespace WinFormInfSys.Window
{
    public partial class Students : Form
    {

        public Students()
        {

            InitializeComponent();

            Binder.bind(GroupList, "is_group", "name");

            buildList();

        }

        private Label buildLabel(int parentWidth, int index, string text)
        {

            Label res = new Label();
            res.Width = parentWidth - res.Width - 10 - 20;
            res.Parent = Container;
            res.Text = text;
            res.Name = $"LabelNum{index}";
            res.Location = new Point(0, index * 25);

            return res;

        }

        private Button buildButton(int titleWidth, string text, int id, string name)
        {

            Button res = new Button();
            res.Text = text;
            res.Parent = Container;
            res.Width = titleWidth;
            res.AutoSize = false;
            res.Name = name;

            return res;

        }

        private void clearList()
        {

            Container.Controls.Clear();

        }

        private void buildList()
        {

            clearList();

            string query = $@"

                select isu.name, isu.login, isu.id, isg.name as groupname, isf.name as faculty, isc.name as course from is_user isu

                left join is_group isg on isg.id = isu.group_id
                left join is_faculty isf on isf.id = isg.faculty_id
                left join is_course isc on isc.id = isg.course_id

                where role_id = 2

            ";

            MySqlConnection conn = DBUtils.getConnection();

            conn.Open();

            MySqlCommand cmd = new MySqlCommand(query, conn);

            MySqlDataReader reader = cmd.ExecuteReader();

            int i = 0;

            while (reader.Read())
            {

                string n = reader["name"].ToString();
                string f = reader["faculty"].ToString();
                string g = reader["groupname"].ToString();
                string c = reader["course"].ToString();
                string login = reader["login"].ToString();

                string add = $"{f},    {g},    {c}";
                if (string.IsNullOrEmpty(g)) { add = "*Не указана группа*"; }

                string str = $"{n}  [ {login} ]    |   {add}";

                Label l = buildLabel((int)(Container.Width * 0.75), i, str);

                Button delete = buildButton((int)(Container.Width * 0.15), "Удалить", int.Parse(reader["id"].ToString()), $"ButtonDelete_{int.Parse(reader["id"].ToString())}");
                delete.Location = new Point(l.Location.X + l.Width + 5, l.Location.Y);
                delete.Click += Delete_Click;

                Button edit = buildButton((int)(Container.Width * 0.20), "Редактировать", int.Parse(reader["id"].ToString()), $"ButtonEdit_{int.Parse(reader["id"].ToString())}");
                edit.Location = new Point(delete.Location.X + delete.Width + 5, l.Location.Y);
                edit.Click += Edit_Click;

                i++;

            }

            conn.Close();

        }

        private void Edit_Click(object sender, EventArgs e)
        {

            int id = int.Parse(((Button)sender).Name.Replace("ButtonEdit_", string.Empty));

            _edit_Students dialog = new _edit_Students(id);

            dialog.ShowDialog();

            buildList();

        }

        private void Delete_Click(object sender, EventArgs e)
        {

            int id = int.Parse(((Button)sender).Name.Replace("ButtonDelete_", string.Empty));

            DialogResult dialogResult = MessageBox.Show("При удалении данных о студенте также будут удалены все его проекты. Продолжить?", "Подтверждение", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.No) { return; }

            DBUtils.removeStudentById(id);

            buildList();

        }

        private void Create_Click(object sender, EventArgs e)
        {

            string login = Login.Text;
            string pass = Password.Text;
            string name = Fio.Text;

            if (DBUtils.userIsExists(login))
            {

                MessageBox.Show("Пользователь с таким логином уже существует");

                return;

            }

            if (string.IsNullOrWhiteSpace(login) 
                || string.IsNullOrWhiteSpace(pass)
                || string.IsNullOrWhiteSpace(name)
                || GroupList.SelectedIndex == -1)
            {

                MessageBox.Show("Проверьте правильность данных");

                return;

            }

            DBUtils.addUser(name, login, pass, GroupList.SelectedItem.ToString(), Role.Student);

            buildList();

        }

    }

}