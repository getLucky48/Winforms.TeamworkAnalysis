﻿
namespace WinFormInfSys
{
    partial class Menu
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.MainPage = new System.Windows.Forms.ToolStripMenuItem();
            this.пройтиТестБелбинаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.дисциплиныToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.опросыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сменитьПользователяToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вызодToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TeacherPage = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьДисциплинуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.GroupPage = new System.Windows.Forms.ToolStripMenuItem();
            this.просмотрГруппToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.изменениеГруппToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DisciplinePage = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.AnalysisPage = new System.Windows.Forms.ToolStripMenuItem();
            this.результатыТестаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.создатьБригадыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.графикиУспеваемостиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.результатыОпросовToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AboutPage = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MainPage,
            this.TeacherPage,
            this.GroupPage,
            this.DisciplinePage,
            this.AnalysisPage,
            this.AboutPage});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(484, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // MainPage
            // 
            this.MainPage.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.пройтиТестБелбинаToolStripMenuItem,
            this.дисциплиныToolStripMenuItem1,
            this.опросыToolStripMenuItem,
            this.сменитьПользователяToolStripMenuItem,
            this.вызодToolStripMenuItem});
            this.MainPage.Name = "MainPage";
            this.MainPage.Size = new System.Drawing.Size(63, 20);
            this.MainPage.Text = "Главная";
            // 
            // пройтиТестБелбинаToolStripMenuItem
            // 
            this.пройтиТестБелбинаToolStripMenuItem.Name = "пройтиТестБелбинаToolStripMenuItem";
            this.пройтиТестБелбинаToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.пройтиТестБелбинаToolStripMenuItem.Text = "Пройти тест Белбина";
            this.пройтиТестБелбинаToolStripMenuItem.Click += new System.EventHandler(this.пройтиТестБелбинаToolStripMenuItem_Click);
            // 
            // дисциплиныToolStripMenuItem1
            // 
            this.дисциплиныToolStripMenuItem1.Name = "дисциплиныToolStripMenuItem1";
            this.дисциплиныToolStripMenuItem1.Size = new System.Drawing.Size(224, 22);
            this.дисциплиныToolStripMenuItem1.Text = "Таблица проектов студента";
            this.дисциплиныToolStripMenuItem1.Click += new System.EventHandler(this.дисциплиныToolStripMenuItem1_Click);
            // 
            // опросыToolStripMenuItem
            // 
            this.опросыToolStripMenuItem.Name = "опросыToolStripMenuItem";
            this.опросыToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.опросыToolStripMenuItem.Text = "Опросы";
            // 
            // сменитьПользователяToolStripMenuItem
            // 
            this.сменитьПользователяToolStripMenuItem.Name = "сменитьПользователяToolStripMenuItem";
            this.сменитьПользователяToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.сменитьПользователяToolStripMenuItem.Text = "Сменить пользователя";
            this.сменитьПользователяToolStripMenuItem.Click += new System.EventHandler(this.сменитьПользователяToolStripMenuItem_Click);
            // 
            // вызодToolStripMenuItem
            // 
            this.вызодToolStripMenuItem.Name = "вызодToolStripMenuItem";
            this.вызодToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.вызодToolStripMenuItem.Text = "Вызод";
            this.вызодToolStripMenuItem.Click += new System.EventHandler(this.вызодToolStripMenuItem_Click);
            // 
            // TeacherPage
            // 
            this.TeacherPage.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.добавитьДисциплинуToolStripMenuItem});
            this.TeacherPage.Name = "TeacherPage";
            this.TeacherPage.Size = new System.Drawing.Size(104, 20);
            this.TeacherPage.Text = "Преподаватели";
            // 
            // добавитьДисциплинуToolStripMenuItem
            // 
            this.добавитьДисциплинуToolStripMenuItem.Name = "добавитьДисциплинуToolStripMenuItem";
            this.добавитьДисциплинуToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.добавитьДисциплинуToolStripMenuItem.Text = "Список преподавателей";
            this.добавитьДисциплинуToolStripMenuItem.Click += new System.EventHandler(this.добавитьДисциплинуToolStripMenuItem_Click);
            // 
            // GroupPage
            // 
            this.GroupPage.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.просмотрГруппToolStripMenuItem,
            this.изменениеГруппToolStripMenuItem});
            this.GroupPage.Name = "GroupPage";
            this.GroupPage.Size = new System.Drawing.Size(61, 20);
            this.GroupPage.Text = "Группы";
            // 
            // просмотрГруппToolStripMenuItem
            // 
            this.просмотрГруппToolStripMenuItem.Name = "просмотрГруппToolStripMenuItem";
            this.просмотрГруппToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.просмотрГруппToolStripMenuItem.Text = "Список групп";
            this.просмотрГруппToolStripMenuItem.Click += new System.EventHandler(this.просмотрГруппToolStripMenuItem_Click);
            // 
            // изменениеГруппToolStripMenuItem
            // 
            this.изменениеГруппToolStripMenuItem.Name = "изменениеГруппToolStripMenuItem";
            this.изменениеГруппToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.изменениеГруппToolStripMenuItem.Text = "Список студентов";
            this.изменениеГруппToolStripMenuItem.Click += new System.EventHandler(this.изменениеГруппToolStripMenuItem_Click);
            // 
            // DisciplinePage
            // 
            this.DisciplinePage.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.toolStripMenuItem4});
            this.DisciplinePage.Name = "DisciplinePage";
            this.DisciplinePage.Size = new System.Drawing.Size(91, 20);
            this.DisciplinePage.Text = "Дисциплины";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(262, 22);
            this.toolStripMenuItem2.Text = "Список дисциплин";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(262, 22);
            this.toolStripMenuItem3.Text = "Добавить задание";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(262, 22);
            this.toolStripMenuItem4.Text = " Таблица проектов преподавателя";
            // 
            // AnalysisPage
            // 
            this.AnalysisPage.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.результатыТестаToolStripMenuItem,
            this.создатьБригадыToolStripMenuItem,
            this.графикиУспеваемостиToolStripMenuItem,
            this.результатыОпросовToolStripMenuItem});
            this.AnalysisPage.Name = "AnalysisPage";
            this.AnalysisPage.Size = new System.Drawing.Size(59, 20);
            this.AnalysisPage.Text = "Анализ";
            // 
            // результатыТестаToolStripMenuItem
            // 
            this.результатыТестаToolStripMenuItem.Name = "результатыТестаToolStripMenuItem";
            this.результатыТестаToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.результатыТестаToolStripMenuItem.Text = "Результаты теста";
            this.результатыТестаToolStripMenuItem.Click += new System.EventHandler(this.результатыТестаToolStripMenuItem_Click);
            // 
            // создатьБригадыToolStripMenuItem
            // 
            this.создатьБригадыToolStripMenuItem.Name = "создатьБригадыToolStripMenuItem";
            this.создатьБригадыToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.создатьБригадыToolStripMenuItem.Text = "Создать бригады";
            this.создатьБригадыToolStripMenuItem.Click += new System.EventHandler(this.создатьБригадыToolStripMenuItem_Click);
            // 
            // графикиУспеваемостиToolStripMenuItem
            // 
            this.графикиУспеваемостиToolStripMenuItem.Name = "графикиУспеваемостиToolStripMenuItem";
            this.графикиУспеваемостиToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.графикиУспеваемостиToolStripMenuItem.Text = "Графики успеваемости";
            // 
            // результатыОпросовToolStripMenuItem
            // 
            this.результатыОпросовToolStripMenuItem.Name = "результатыОпросовToolStripMenuItem";
            this.результатыОпросовToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.результатыОпросовToolStripMenuItem.Text = "Результаты опросов";
            // 
            // AboutPage
            // 
            this.AboutPage.Name = "AboutPage";
            this.AboutPage.Size = new System.Drawing.Size(65, 20);
            this.AboutPage.Text = "Справка";
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 348);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Menu";
            this.Text = "Информационная система";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem MainPage;
        private System.Windows.Forms.ToolStripMenuItem пройтиТестБелбинаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сменитьПользователяToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вызодToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem GroupPage;
        private System.Windows.Forms.ToolStripMenuItem TeacherPage;
        private System.Windows.Forms.ToolStripMenuItem добавитьДисциплинуToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem AnalysisPage;
        private System.Windows.Forms.ToolStripMenuItem результатыТестаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem создатьБригадыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem AboutPage;
        private System.Windows.Forms.ToolStripMenuItem дисциплиныToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem графикиУспеваемостиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem просмотрГруппToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem изменениеГруппToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem DisciplinePage;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem опросыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem результатыОпросовToolStripMenuItem;
    }
}

