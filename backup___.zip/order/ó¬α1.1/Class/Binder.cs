﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormInfSys.Class
{
    public class Binder
    {

        public static void bind(ComboBox comboBox, string bindClass, string bindProperty, bool distinct = false, string customWhere = "")
        {

            string query = $"select {(distinct ? "distinct" : "") } {bindProperty} from {bindClass} ";

            if (!string.IsNullOrEmpty(customWhere)) { query += customWhere; }

            MySqlConnection connection = DBUtils.getConnection();

            connection.Open();

            MySqlCommand cmd = new MySqlCommand(query, connection);

            MySqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {

                comboBox.Items.Add(reader[bindProperty]);

            }

            connection.Close();

        }

        public static void bind(TextBox textBox, string bindProperty, string query)
        {

            MySqlConnection connection = DBUtils.getConnection();

            connection.Open();

            MySqlCommand cmd = new MySqlCommand(query, connection);

            MySqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {

                textBox.Text = reader[bindProperty].ToString();

                break;

            }

            connection.Close();

        }

        public static void selectItem(ComboBox comboBox, string bindProperty, MySqlDataReader reader)
        {

            string target = reader[bindProperty].ToString();

            int indxGroup = comboBox.Items.IndexOf(target);

            comboBox.SelectedIndex = indxGroup;

        }

        public static void selectItem(ComboBox comboBox, string srcClass, string srcProperty, string distClass, string distProperty, string getProperty, int srcId)
        {

            string query = $@"

                select dist.{getProperty} from {srcClass} src

                join {distClass} dist on src.{srcProperty} = dist.{distProperty}

                where src.id = '{srcId}'

                limit 1

            ";

            MySqlConnection connection = DBUtils.getConnection();

            connection.Open();

            MySqlCommand cmd = new MySqlCommand(query, connection);

            MySqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {

                string target = reader[0].ToString();

                int indx = comboBox.Items.IndexOf(target);

                comboBox.SelectedIndex = indx;

                break;

            }

            connection.Close();

        }

    }

}
